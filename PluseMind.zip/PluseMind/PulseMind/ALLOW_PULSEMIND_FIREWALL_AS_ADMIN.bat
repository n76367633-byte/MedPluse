@echo off
echo This adds a Windows Firewall rule so phones on your Wi-Fi can open PulseMind.
echo If Windows asks for permission, choose Yes.
netsh advfirewall firewall add rule name="PulseMind Mobile 8788" dir=in action=allow protocol=TCP localport=8788 profile=private
echo.
echo Done. Now open this on your phone:
echo http://192.168.1.3:8788/
pause
