@echo off
cd /d "%~dp0"
python pulsemind_complete.py
pause
