PulseMind Complete - Deployment Notes

Final app file:
  pulsemind_complete.py

Run locally:
  python pulsemind_complete.py

Optional Windows launcher:
  RUN_PULSEMIND.bat

Open on the host computer:
  http://127.0.0.1:8788

Open on phones on the same Wi-Fi:
  http://YOUR-COMPUTER-IP:8788

Important:
  Do not share or open index.html as a file:// link for mobile use. PulseMind is now
  served by Python so the app, AEGIS API, diet plan API, manifest, and mobile browser
  loading all come from the same server.

AEGIS / DeepSeek:
  The user phone does not run Ollama or DeepSeek. Only the host computer/server needs
  Ollama and the deepseek-r1:8b model. Phones open the PulseMind URL and call the
  server API.

  Default settings:
    OLLAMA_HOST=http://127.0.0.1:11434
    OLLAMA_MODEL=deepseek-r1:8b

  You can change them before running:
    set OLLAMA_HOST=http://127.0.0.1:11434
    set OLLAMA_MODEL=deepseek-r1:8b
    python pulsemind_complete.py

Internet users:
  To make AEGIS work for users outside your Wi-Fi, run pulsemind_complete.py on your
  always-on host computer or server, keep Ollama running there, and expose the app
  through HTTPS using a hosting server, reverse proxy, Cloudflare Tunnel, or a similar
  secure tunnel. Other users still do not install the model.

Google Maps:
  PulseMind uses normal Google Maps website search links only. It does not use the
  Google Maps API, does not need an API key, and does not create Google billing.

Health safety:
  PulseMind and AEGIS are wellness support tools. They do not replace a doctor,
  pharmacist, emergency service, or local medical authority.
