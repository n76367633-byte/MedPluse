#!/usr/bin/env python3
"""
PulseMind Complete

One deployable server file for the PulseMind mobile health app.

Run on the device/server that has Ollama + deepseek-r1:8b:
    python pulsemind_complete.py

Open on the same device:
    http://127.0.0.1:8788

Open on phones on the same Wi-Fi:
    http://YOUR-COMPUTER-IP:8788

For internet users, deploy this server behind HTTPS or a tunnel. The AI model runs
only on the server machine; user phones only use the web app and API.
"""

from __future__ import annotations

import json
import os
import re
import socket
import sys
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse

APP_HOST = os.getenv("PULSEMIND_HOST", "0.0.0.0")
APP_PORT = int(os.getenv("PULSEMIND_PORT", "8788"))
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "deepseek-r1:8b")
REQUEST_LIMIT = 2_000_000

SYSTEM_PROMPT = """You are AEGIS inside PulseMind, a medical and health intelligence assistant.

Safety rules:
- You do not replace a doctor, pharmacist, emergency service, or local medical authority.
- Do not diagnose with certainty, prescribe medicines, or give exact prescription dosing.
- For emergency warning signs, first advise immediate emergency care.
- Use the PulseMind profile, vitals, logs, menstrual cycle, circadian rhythm, medication, and journal context when relevant.
- Be practical, concise, empathetic, and safe.
"""


def json_bytes(data: Any) -> bytes:
    return json.dumps(data, ensure_ascii=False).encode("utf-8")


def safe_text(value: Any, limit: int = 12000) -> str:
    return str(value or "")[:limit]


def request_path(path: str) -> str:
    return (urlparse(path).path or "/").rstrip("/") or "/"


def local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            return sock.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def ollama_status() -> dict[str, Any]:
    try:
        with urllib.request.urlopen(f"{OLLAMA_HOST}/api/tags", timeout=2) as response:
            data = json.loads(response.read().decode("utf-8"))
        models = []
        for item in data.get("models", []):
            name = item.get("name") or item.get("model")
            if name:
                models.append(name)
        return {
            "ollama_running": True,
            "model": OLLAMA_MODEL,
            "model_ready": OLLAMA_MODEL in models,
            "available_models": models,
        }
    except Exception:
        return {
            "ollama_running": False,
            "model": OLLAMA_MODEL,
            "model_ready": False,
            "available_models": [],
        }


def call_ollama(prompt: str, context: dict[str, Any], timeout: int = 120) -> str:
    compact_context = json.dumps(context, ensure_ascii=False)[:18000]
    payload = {
        "model": OLLAMA_MODEL,
        "stream": False,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"PulseMind context JSON:\n{compact_context}\n\nUser request:\n{prompt}"},
        ],
        "options": {
            "temperature": 0.2,
            "top_p": 0.85,
            "num_ctx": 4096,
            "num_predict": 600,
        },
    }
    req = urllib.request.Request(
        f"{OLLAMA_HOST}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        data = json.loads(response.read().decode("utf-8"))
    text = data.get("message", {}).get("content", "")
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    return text.strip()


def emergency_risk(text: str) -> bool:
    lower = " ".join(text.lower().split())
    patterns = [
        "chest pain",
        "chest pressure",
        "can't breathe",
        "cannot breathe",
        "severe shortness of breath",
        "stroke",
        "slurred speech",
        "face droop",
        "unconscious",
        "seizure",
        "severe bleeding",
        "overdose",
        "poison",
        "suicide",
        "kill myself",
        "self harm",
        "throat swelling",
    ]
    return any(item in lower for item in patterns)


def fallback_chat(message: str, context: dict[str, Any]) -> str:
    if emergency_risk(message):
        return (
            "AEGIS safety alert: this may be urgent. Call emergency services now or go to the nearest emergency department. "
            "Do not wait for an app response for chest pain, severe breathing trouble, stroke signs, fainting, seizure, poisoning, severe allergy, uncontrolled bleeding, or self-harm risk."
        )
    if any(word in message.lower() for word in ("diet", "food", "meal", "protein", "calorie", "nutrition")):
        return fallback_diet(context)
    profile = context.get("profile") or {}
    today = context.get("today") or {}
    return (
        f"AEGIS quick answer for {profile.get('name', 'you')}:\n\n"
        "I can use your PulseMind data as context, but I cannot diagnose or replace a clinician.\n\n"
        f"Current signals: {today.get('steps', 0)} steps, {today.get('water', 0)} ml water, "
        f"{today.get('sleep', 0)} h sleep, {today.get('protein', 0)} g protein, "
        f"mood {today.get('mood', 'unknown')}/5, stress {today.get('stress', 'unknown')}/5.\n\n"
        "Track timing, severity, triggers, food, water, sleep, medicines, and vitals. Seek urgent care for severe or sudden symptoms."
    )


def fallback_diet(context: dict[str, Any]) -> str:
    profile = context.get("profile") or {}
    goals = context.get("goals") or {}
    bmi = context.get("bmi") or {}
    today = context.get("today") or {}
    cycle = context.get("cycle")
    rhythm = context.get("rhythm")
    name = profile.get("name") or "User"
    calories = goals.get("calories") or "custom"
    protein = goals.get("protein") or "custom"
    water = goals.get("water") or "custom"
    timing = "Keep regular meal timing and avoid very heavy late dinners."
    if cycle:
        timing = f"Cycle context: {cycle.get('phase')} day {cycle.get('day')}. During period days, add iron-rich foods and vitamin C."
    if rhythm:
        timing = (
            f"Circadian context: wake {rhythm.get('wakeTime')}, caffeine cutoff {rhythm.get('caffeineCutoff')}, "
            f"wind-down {rhythm.get('windDown')}. Keep dinner 2-3 hours before bedtime."
        )
    return (
        f"1. Diet summary\nPersonal diet plan for {name}. BMI: {bmi.get('value', 'unknown')} ({bmi.get('label', 'unknown')}).\n\n"
        f"2. Daily targets\nAbout {calories} kcal, {protein} g protein, and {water} ml water. Adjust slowly based on weekly progress.\n\n"
        "3. Meal plan\n"
        "- Breakfast: protein plus slow carbs, such as eggs, paneer, tofu, curd, dal chilla, oats, poha, upma, roti, or fruit.\n"
        "- Lunch: dal, chana, rajma, paneer, tofu, chicken, fish, or eggs with rice, roti, millet, vegetables, curd, and salad.\n"
        "- Snack: fruit with nuts, roasted chana, sprouts, yogurt, peanut butter toast, or a milk/curd smoothie.\n"
        "- Dinner: lighter protein, cooked vegetables, and moderate carbs. Reduce fried foods if sleep, gut, or energy is poor.\n\n"
        f"4. Timing guidance\n{timing}\n\n"
        f"5. PulseMind adjustments\nToday shows {today.get('steps', 0)} steps, {today.get('water', 0)} ml water, "
        f"{today.get('sleep', 0)} h sleep, and {today.get('protein', 0)} g protein. Improve the weakest signal first.\n\n"
        "6. Safety notes\nThis is wellness guidance, not a prescription. Confirm major diet changes with a clinician or dietitian if you have diabetes, kidney/liver disease, allergies, pregnancy, eating disorder symptoms, unexplained weight change, or regular medicines."
    )


def diet_prompt(context: dict[str, Any]) -> str:
    return (
        "Automatically create a personalized diet plan from PulseMind data. Include: diet summary, daily targets, meal plan, meal timing, "
        "adjustments from logs/vitals/cycle/rhythm, and safety notes. Use practical Indian food options unless the user context asks otherwise."
    )


APP_HTML = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#0f766e">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="PulseMind">
  <link rel="manifest" href="manifest.webmanifest">
  <title>PulseMind Complete</title>
  <style>
    :root{--bg:#f7fbf8;--ink:#17211f;--muted:#64716d;--line:#d9e6df;--card:#fff;--teal:#0f766e;--blue:#2563eb;--rose:#be3455;--coral:#dc6b2f;--green:#15803d;--amber:#b7791f;--navy:#18324a;--shadow:0 18px 48px rgba(20,35,32,.14);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color-scheme:light}
    *{box-sizing:border-box} body{margin:0;background:#e9f2ee;color:var(--ink)} button,input,select,textarea{font:inherit} button{cursor:pointer;-webkit-tap-highlight-color:transparent}
    .app{max-width:520px;min-height:100vh;margin:0 auto;background:var(--bg);box-shadow:0 0 0 1px rgba(0,0,0,.06),0 18px 70px rgba(20,35,32,.22);position:relative}
    .screen{min-height:100vh;padding:14px 14px 96px}.top{position:sticky;top:0;z-index:5;margin:0 -14px 10px;padding:10px 14px;background:rgba(247,251,248,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:space-between;gap:10px}
    .brand{display:flex;align-items:center;gap:10px}.logo{width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,var(--teal),var(--blue),var(--coral));display:grid;place-items:center;color:white;font-weight:900}.top h1{font-size:1.05rem;margin:0}.sub{margin:2px 0 0;color:var(--muted);font-size:.78rem}
    .avatar{width:40px;height:40px;border-radius:50%;background:#193b36;color:white;display:grid;place-items:center;font-weight:900}.hero{padding:18px 0}.hero h2{font-size:2.35rem;line-height:.98;margin:12px 0 8px;letter-spacing:0}.hero p,.helper{color:var(--muted);line-height:1.45;margin:0}
    .card,.panel{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px}.panel{box-shadow:var(--shadow)}.grid{display:grid;gap:10px}.two{display:grid;grid-template-columns:1fr 1fr;gap:10px}.cards{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    label{font-size:.82rem;font-weight:800}.field{display:grid;gap:6px}.input,.select,.textarea{width:100%;min-height:46px;padding:10px 12px;border:1px solid #c8d8d1;border-radius:8px;background:#fbfdfc;color:var(--ink)}.textarea{min-height:92px;resize:vertical}
    .btn{min-height:44px;border:1px solid var(--line);border-radius:8px;background:#edf5f2;color:var(--ink);font-weight:850;padding:10px 12px;display:inline-flex;align-items:center;justify-content:center;gap:7px;text-decoration:none}.btn.primary{background:var(--teal);color:white;border-color:var(--teal);box-shadow:0 12px 26px rgba(15,118,110,.24)}.btn.danger{background:#fff1f3;color:var(--rose)}
    .section{margin-top:16px}.head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px}.head h2,.head h3{margin:0;font-size:1rem}.tag{display:inline-flex;align-items:center;min-height:28px;padding:5px 9px;border-radius:999px;background:#e7f6f2;color:var(--teal);font-size:.74rem;font-weight:850}
    .score{display:grid;grid-template-columns:126px 1fr;gap:14px;align-items:center;border-radius:16px;padding:14px;background:linear-gradient(135deg,var(--teal),var(--navy));color:white}.ring{--score:0;width:120px;aspect-ratio:1;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle,#18324a 0 56%,transparent 57%),conic-gradient(#9be7c9 calc(var(--score)*1%),rgba(255,255,255,.25) 0)}.ring strong{font-size:2rem}.score h2{margin:0 0 6px}.score p{margin:0;color:rgba(255,255,255,.82);line-height:1.4}
    .metric{background:white;border:1px solid var(--line);border-radius:10px;padding:12px;min-height:118px}.metric small{color:var(--muted);font-weight:800;text-transform:uppercase}.metric strong{display:block;font-size:1.35rem;margin:3px 0}.bar{height:8px;border-radius:999px;background:#edf3f0;overflow:hidden;margin-top:9px}.bar span{display:block;height:100%;width:var(--v);background:var(--c,var(--teal));border-radius:999px}
    .nav{position:fixed;left:50%;bottom:0;z-index:10;width:min(100%,520px);transform:translateX(-50%);display:flex;gap:4px;overflow-x:auto;padding:8px 8px calc(8px + env(safe-area-inset-bottom));background:rgba(255,255,255,.97);border-top:1px solid var(--line);box-shadow:0 -8px 30px rgba(20,35,32,.08)}.nav button{flex:0 0 70px;min-height:54px;border:0;border-radius:8px;background:transparent;color:var(--muted);font-size:.68rem;font-weight:850}.nav button.active{background:#e7f6f2;color:var(--teal)}
    .fab{position:fixed;right:max(14px,calc((100vw - min(100%,520px))/2 + 14px));bottom:88px;z-index:12;width:58px;height:58px;border-radius:50%;border:1px solid rgba(255,255,255,.6);background:var(--blue);color:white;font-weight:900;box-shadow:0 16px 34px rgba(37,99,235,.32)}
    .heroBand{border-radius:16px;padding:14px;color:white;background:linear-gradient(135deg,var(--blue),var(--teal))}.heroBand h2{margin:4px 0;font-size:1.45rem}.heroBand p{margin:0;color:rgba(255,255,255,.84);line-height:1.42}.cycle{background:linear-gradient(135deg,var(--rose),var(--coral))}.rhythm{background:linear-gradient(135deg,var(--navy),var(--teal))}
    .list{display:grid;gap:8px;padding:0;margin:0;list-style:none}.item{display:grid;grid-template-columns:72px 1fr;gap:10px;border:1px solid var(--line);background:#f9fbfa;border-radius:8px;padding:10px}.date{font-size:.74rem;font-weight:900;color:var(--teal)}
    .chat{display:grid;gap:10px}.bubble{max-width:92%;border:1px solid var(--line);border-radius:10px;padding:10px;background:white}.bubble.user{justify-self:end;background:#eaf0ff}.bubble.assistant{justify-self:start}.bubble b{display:block;color:var(--teal);font-size:.72rem;text-transform:uppercase}.bubble p,.pre{white-space:pre-wrap;line-height:1.48;margin:4px 0 0}.pre{font-family:inherit;font-size:.9rem;max-height:460px;overflow:auto}.hidden{display:none!important}
    @media(max-width:370px){.two,.cards{grid-template-columns:1fr}.score{grid-template-columns:1fr}.ring{margin:auto}.hero h2{font-size:2rem}}
  </style>
</head>
<body>
  <div id="root" class="app"></div>
  <script>
  const KEY='pulsemind.complete.v1';
  const DEFAULT_API='http://192.168.1.3:8788';
  let state=load(), view='today', chatBusy=false, dietBusy=false, dietPlan='', dietSource='Preview';
  let chat=[{role:'assistant',text:'Ask AEGIS anything. I can use your PulseMind profile, logs, vitals, cycle, rhythm, medication, and journals as context.'}];
  function apiUrl(path){if(location.protocol==='http:'||location.protocol==='https:')return path;return (localStorage.getItem('pulsemind.server')||DEFAULT_API).replace(/\/$/,'')+path}
  function load(){try{const raw=window.localStorage&&localStorage.getItem(KEY);return raw?JSON.parse(raw):blank()}catch(e){return blank()}}
  function save(){try{if(window.localStorage)localStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
  function resetStore(){try{if(window.localStorage)localStorage.removeItem(KEY)}catch(e){}}
  function formVals(f){const o={};for(let i=0;i<f.elements.length;i++){const el=f.elements[i];if(!el.name)continue;if((el.type==='checkbox'||el.type==='radio')&&!el.checked)continue;o[el.name]=el.value||'on'}return o}
  function blank(){return{profile:null,daily:{},vitals:[],meds:[],journals:[],cycleLogs:[],reminders:[]}}
  function today(){return new Date().toISOString().slice(0,10)}
  function day(d=today()){return Object.assign({steps:0,water:0,sleep:0,exercise:0,calories:0,protein:0,mood:3,energy:3,stress:3,meditation:0,notes:'',symptoms:'',morningLight:0,outdoorTime:0,caffeineAfterCutoff:'no',screenCurfew:'no',sleepQuality:3,wakeTime:'',bedTime:''},state.daily[d]||{})}
  function setDay(d,obj){state.daily[d]=Object.assign(day(d),obj);save()}
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
  function num(v,f=0){v=Number(v);return Number.isFinite(v)?v:f}
  function pct(v,g){return Math.max(0,Math.min(100,Math.round(num(v)/num(g,1)*100)))}
  function goals(){const p=state.profile||{},w=num(p.weight,70),h=num(p.height,170),a=num(p.age,30),sex=p.gender;let b=10*w+6.25*h-5*a+(sex==='male'?5:sex==='female'?-161:-78);return{steps:a>=60?6500:8500,water:Math.max(1800,Math.round(w*35/250)*250),sleep:a<18?9:8,exercise:30,calories:Math.max(1400,Math.round(b*1.35)),protein:Math.max(45,Math.round(w*.9)),meditation:10}}
  function bmi(){const p=state.profile||{},h=num(p.height)/100,w=latest('weight')||num(p.weight);if(!h||!w)return{value:'--',label:'Add height and weight'};const b=w/(h*h);return{value:Math.round(b*10)/10,label:b<18.5?'Below typical range':b>=30?'High range':b>=25?'Above typical range':'Balanced range'}}
  function latest(k){for(let i=state.vitals.length-1;i>=0;i--)if(state.vitals[i][k])return state.vitals[i][k];return''}
  function score(){const d=day(),g=goals();return Math.round(pct(d.water,g.water)*.18+pct(d.steps,g.steps)*.18+pct(d.sleep,g.sleep)*.16+pct(d.exercise,g.exercise)*.12+pct(d.protein,g.protein)*.11+num(d.mood,3)/5*100*.1+(6-num(d.stress,3))/5*100*.1+pct(d.meditation,g.meditation)*.05)}
  function isFemale(){return !!(state.profile&&state.profile.gender==='female')} function isMale(){return !!(state.profile&&state.profile.gender==='male')}
  function addDays(s,n){let d=new Date(s+'T00:00:00');d.setDate(d.getDate()+n);return d.toISOString().slice(0,10)} function diff(a,b){return Math.round((new Date(b)-new Date(a))/86400000)}
  function fmtDate(s){return new Date(s+'T00:00:00').toLocaleDateString(undefined,{month:'short',day:'numeric'})}
  function minTime(t,f=0){let m=String(t||'').match(/^(\d+):(\d\d)$/);return m?num(m[1])*60+num(m[2]):f} function toTime(m){m=((Math.round(m)%1440)+1440)%1440;return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0')} function pretty(t){let m=minTime(t),h=Math.floor(m/60),s=h>=12?'PM':'AM';return (h%12||12)+':'+String(m%60).padStart(2,'0')+' '+s}
  function cycleInfo(){const c=(state.profile&&state.profile.cycle)||{},start=c.lastPeriod||addDays(today(),-14),len=num(c.cycleLength,28),per=num(c.periodLength,5),d=(Math.max(0,diff(start,today()))%len)+1,ovu=Math.max(10,len-14),fs=ovu-5,fe=ovu+1;let phase=d<=per?'Period phase':d<fs?'Follicular phase':d<=fe?'Fertile window':'Luteal phase';return{start,len,per,day:d,phase,ovu,fs,fe,next:addDays(start,(Math.floor(diff(start,today())/len)+1)*len)}}
  function rhythmInfo(){const r=(state.profile&&state.profile.rhythm)||{},d=day(),wake=d.wakeTime||r.wakeTime||'06:30',bed=d.bedTime||r.bedTime||'22:30',wm=minTime(wake,390),bm=minTime(bed,1350),cut=toTime(wm+480),wind=toTime(bm-90);let sc=Math.round(pct(d.morningLight,20)*.25+pct(d.outdoorTime,45)*.15+pct(d.sleep,goals().sleep)*.2+num(d.sleepQuality,3)/5*100*.15+(d.caffeineAfterCutoff==='yes'?35:100)*.15+(d.screenCurfew==='yes'?100:60)*.1);return{wakeTime:wake,bedTime:bed,caffeineCutoff:cut,windDown:wind,phase:'Circadian rhythm',score:Math.max(0,Math.min(100,sc))}}
  function context(){return{profile:state.profile,goals:goals(),bmi:bmi(),today:day(),daily:state.daily,vitals:state.vitals,medications:state.meds,journals:state.journals,cycleLogs:state.cycleLogs,cycle:isFemale()?cycleInfo():null,rhythm:isMale()?rhythmInfo():null}}
  function appTop(){const p=state.profile||{};return `<header class="top"><div class="brand"><div class="logo">PM</div><div><h1>${esc(p.name||'PulseMind')}</h1><p class="sub">${new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'})}</p></div></div><div class="avatar">${esc((p.name||'P')[0].toUpperCase())}</div></header>`}
  function nav(){let items=[['today','Today'],['body','Body'],['mind','Mind']];if(isFemale())items.push(['cycle','Cycle']);if(isMale())items.push(['rhythm','Rhythm']);items.push(['diet','Diet'],['insights','Insights'],['profile','Profile']);return `<nav class="nav">${items.map(i=>`<button class="${view===i[0]?'active':''}" data-view="${i[0]}">${i[1]}</button>`).join('')}</nav><button class="fab" data-view="chat">AI</button>`}
  function render(){if(!state.profile){root.innerHTML=onboard();bindOnboard();return}root.innerHTML=`<main class="screen">${appTop()}${viewHtml()}</main>${nav()}`;if(view==='diet'&&!dietPlan&&!dietBusy)setTimeout(generateDiet,0)}
  function onboard(){return `<main class="screen"><div class="brand"><div class="logo">PM</div><div><h1>PulseMind</h1><p class="sub">Complete mobile health app</p></div></div><section class="hero"><h2>Your whole health, one daily rhythm.</h2><p>Body, mind, diet, menstrual cycle, male circadian rhythm, vitals, maps links, and AEGIS AI.</p></section><form class="panel grid" id="onboard"><div class="field"><label>Name</label><input class="input" name="name" required></div><div class="two"><div class="field"><label>Age</label><input class="input" name="age" type="number" required></div><div class="field"><label>Gender</label><select class="select" name="gender" id="gender" required><option value="">Select</option><option value="female">Female</option><option value="male">Male</option><option value="other">Other</option></select></div></div><div class="two"><div class="field"><label>Height cm</label><input class="input" name="height" type="number" required></div><div class="field"><label>Weight kg</label><input class="input" name="weight" type="number" step=".1" required></div></div><div class="field"><label>Focus</label><select class="select" name="focus"><option value="balanced">Balanced health</option><option value="fat-loss">Fat loss</option><option value="muscle-gain">Muscle gain</option><option value="stress">Stress and sleep</option><option value="circadian">Circadian rhythm</option><option value="cycle">Cycle awareness</option></select></div><section id="femaleBox" class="grid hidden"><div class="head"><h2>Menstrual setup</h2><span class="tag">Female</span></div><div class="two"><div class="field"><label>Last period start</label><input class="input" name="lastPeriod" type="date" value="${addDays(today(),-14)}"></div><div class="field"><label>Cycle length</label><input class="input" name="cycleLength" type="number" value="28"></div></div><div class="field"><label>Period length</label><input class="input" name="periodLength" type="number" value="5"></div></section><section id="maleBox" class="grid hidden"><div class="head"><h2>Circadian setup</h2><span class="tag">Male</span></div><div class="two"><div class="field"><label>Wake time</label><input class="input" name="wakeTime" type="time" value="06:30"></div><div class="field"><label>Bedtime</label><input class="input" name="bedTime" type="time" value="22:30"></div></div></section><button class="btn primary">Start PulseMind</button><p class="helper">Open through the server URL, not by sharing this HTML file. AEGIS runs on the host server.</p></form></main>`}
  function bindOnboard(){gender.onchange=()=>{femaleBox.classList.toggle('hidden',gender.value!=='female');maleBox.classList.toggle('hidden',gender.value!=='male')}}
  function viewHtml(){return ({today:todayView,body:bodyView,mind:mindView,cycle:cycleView,rhythm:rhythmView,diet:dietView,insights:insightsView,profile:profileView,chat:chatView}[view]||todayView)()}
  function metric(t,v,n,p,c){return `<article class="metric"><small>${t}</small><strong>${v}</strong><div class="sub">${n}</div><div class="bar"><span style="--v:${p}%;--c:${c||'var(--teal)'}"></span></div></article>`}
  function todayView(){const d=day(),g=goals(),s=score();return `<section class="score"><div class="ring" style="--score:${s}"><div><strong>${s}</strong><div>score</div></div></div><div><h2>${s>=80?'Excellent rhythm':s>=60?'Strong day':'Needs care'}</h2><p>${s>=80?'Your main habits are lining up.':'Start with water, movement, and sleep consistency.'}</p></div></section><section class="section"><div class="head"><h2>Today</h2><span class="tag">${esc(state.profile.focus)}</span></div><div class="cards">${metric('Steps',d.steps.toLocaleString(),g.steps+' target',pct(d.steps,g.steps),'var(--blue)')}${metric('Water',d.water+' ml',g.water+' target',pct(d.water,g.water))}${metric('Sleep',d.sleep+' h',g.sleep+' h target',pct(d.sleep,g.sleep),'var(--coral)')}${metric('Protein',d.protein+' g',g.protein+' g target',pct(d.protein,g.protein),'var(--green)')}</div></section><section class="section"><form class="card grid" id="daily"><div class="two"><div class="field"><label>Steps</label><input class="input" name="steps" type="number" value="${d.steps}"></div><div class="field"><label>Water ml</label><input class="input" name="water" type="number" value="${d.water}"></div></div><div class="two"><div class="field"><label>Sleep h</label><input class="input" name="sleep" type="number" step=".1" value="${d.sleep}"></div><div class="field"><label>Exercise min</label><input class="input" name="exercise" type="number" value="${d.exercise}"></div></div><div class="two"><div class="field"><label>Calories</label><input class="input" name="calories" type="number" value="${d.calories}"></div><div class="field"><label>Protein g</label><input class="input" name="protein" type="number" value="${d.protein}"></div></div><div class="two"><div class="field"><label>Mood 1-5</label><input class="input" name="mood" type="number" min="1" max="5" value="${d.mood}"></div><div class="field"><label>Stress 1-5</label><input class="input" name="stress" type="number" min="1" max="5" value="${d.stress}"></div></div><div class="field"><label>Notes</label><textarea class="textarea" name="notes">${esc(d.notes)}</textarea></div><button class="btn primary">Save today</button></form></section>`}
  function bodyView(){return `<section class="heroBand"><span class="tag">Body</span><h2>Vitals and care</h2><p>Track weight, pulse, blood pressure, oxygen, glucose, and symptoms.</p></section><section class="section"><div class="cards">${metric('BMI',bmi().value,bmi().label,100)}${metric('Heart rate',latest('heartRate')?latest('heartRate')+' bpm':'--','Latest',latest('heartRate')?100:0,'var(--rose)')}</div></section><section class="section"><form class="card grid" id="vitals"><div class="two"><div class="field"><label>Weight kg</label><input class="input" name="weight" type="number" step=".1"></div><div class="field"><label>Heart rate</label><input class="input" name="heartRate" type="number"></div></div><div class="two"><div class="field"><label>Systolic</label><input class="input" name="systolic" type="number"></div><div class="field"><label>Diastolic</label><input class="input" name="diastolic" type="number"></div></div><div class="two"><div class="field"><label>Oxygen %</label><input class="input" name="oxygen" type="number"></div><div class="field"><label>Temperature C</label><input class="input" name="temperature" type="number" step=".1"></div></div><div class="field"><label>Symptoms</label><textarea class="textarea" name="symptoms"></textarea></div><button class="btn primary">Save vitals</button></form></section>${history(state.vitals,'Vitals history')}`}
  function mindView(){const d=day();return `<section class="heroBand"><span class="tag">Mind</span><h2>Mood, stress, journal</h2><p>Track mental energy beside body signals.</p></section><section class="section"><div class="cards">${metric('Mood',d.mood+'/5','Today',d.mood/5*100)}${metric('Stress',d.stress+'/5','Lower is better',(6-d.stress)/5*100,'var(--rose)')}</div></section><section class="section"><form class="card grid" id="journal"><div class="field"><label>Journal</label><textarea class="textarea" name="note" required></textarea></div><button class="btn primary">Save journal</button></form></section>${history(state.journals,'Journal')}`}
  function cycleView(){if(!isFemale())return'';const c=cycleInfo();return `<section class="heroBand cycle"><span class="tag">Cycle day ${c.day}</span><h2>${c.phase}</h2><p>Next predicted period: ${fmtDate(c.next)}. Predictions are estimates.</p></section><section class="section"><div class="cards">${metric('Cycle length',c.len+' days','Profile',100)}${metric('Period length',c.per+' days','Profile',100)}${metric('Ovulation','Day '+c.ovu,'Estimate',100)}${metric('Fertile','Day '+c.fs+'-'+c.fe,'Estimate',100)}</div></section><section class="section"><form class="card grid" id="cycleLog"><div class="field"><label>Flow</label><select class="select" name="flow"><option>none</option><option>spotting</option><option>light</option><option>medium</option><option>heavy</option></select></div><div class="field"><label>Symptoms</label><textarea class="textarea" name="symptoms"></textarea></div><label><input type="checkbox" name="periodStarted"> Period started today</label><button class="btn primary">Save cycle</button></form></section>${history(state.cycleLogs,'Cycle history')}`}
  function rhythmView(){if(!isMale())return'';const r=rhythmInfo(),d=day();return `<section class="heroBand rhythm"><span class="tag">Male rhythm</span><h2>Circadian rhythm</h2><p>Wake ${pretty(r.wakeTime)}, caffeine cutoff ${pretty(r.caffeineCutoff)}, wind-down ${pretty(r.windDown)}.</p></section><section class="section"><div class="cards">${metric('Rhythm score',r.score+'/100',r.phase,r.score)}${metric('Morning light',d.morningLight+' min','20 min target',pct(d.morningLight,20),'var(--amber)')}${metric('Outdoor',d.outdoorTime+' min','45 min target',pct(d.outdoorTime,45),'var(--green)')}${metric('Sleep quality',d.sleepQuality+'/5','Today',d.sleepQuality/5*100,'var(--blue)')}</div></section><section class="section"><form class="card grid" id="rhythmLog"><div class="two"><div class="field"><label>Wake time</label><input class="input" name="wakeTime" type="time" value="${r.wakeTime}"></div><div class="field"><label>Bedtime</label><input class="input" name="bedTime" type="time" value="${r.bedTime}"></div></div><div class="two"><div class="field"><label>Morning light min</label><input class="input" name="morningLight" type="number" value="${d.morningLight}"></div><div class="field"><label>Outdoor min</label><input class="input" name="outdoorTime" type="number" value="${d.outdoorTime}"></div></div><div class="two"><div class="field"><label>Sleep quality 1-5</label><input class="input" name="sleepQuality" type="number" min="1" max="5" value="${d.sleepQuality}"></div><div class="field"><label>Caffeine after cutoff</label><select class="select" name="caffeineAfterCutoff"><option value="no">No</option><option value="yes">Yes</option></select></div></div><label><input type="checkbox" name="screenCurfew"> Screen/light curfew followed</label><button class="btn primary">Save rhythm</button></form></section>`}
  async function generateDiet(){dietBusy=true;render();try{const res=await fetch(apiUrl('/api/aegis/diet'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({context:context()})});const j=await res.json();dietPlan=j.answer||localDiet();dietSource=j.source||'AEGIS'}catch(e){dietPlan=localDiet();dietSource='Local fallback'}dietBusy=false;render()}
  function localDiet(){return `AEGIS diet preview\n\n${state.profile.name}, your target is about ${goals().calories} kcal, ${goals().protein} g protein, and ${goals().water} ml water.\n\nBreakfast: protein plus slow carbs.\nLunch: protein, rice/roti/millet, vegetables, curd/salad.\nSnack: fruit, nuts, roasted chana, sprouts, yogurt.\nDinner: lighter protein, vegetables, moderate carbs.\n\nSafety: confirm major diet changes for medical conditions, allergies, pregnancy, eating disorder symptoms, or regular medicines.`}
  function dietView(){return `<section class="heroBand"><span class="tag">Automatic AEGIS plan</span><h2>Diet plan</h2><p>Generated from profile, logs, vitals, medication, notes, cycle, and rhythm data.</p></section><section class="section"><div class="card grid"><div class="head"><h3>AEGIS suggestion</h3><span class="tag">${dietBusy?'Generating':dietSource}</span></div><button class="btn primary" data-action="diet">${dietBusy?'Generating':'Refresh diet plan'}</button></div></section><section class="section"><div class="card"><pre class="pre">${esc(dietPlan||localDiet())}</pre></div></section>`}
  function insightsView(){return `<section class="heroBand"><span class="tag">Care links</span><h2>No-key maps and insights</h2><p>Google Maps opens as normal website links. No API key, no billing.</p></section><section class="section"><div class="cards"><button class="btn" data-map="hospital">Hospitals near me</button><button class="btn" data-map="pharmacy">Pharmacy near me</button><button class="btn" data-map="clinic">Clinics near me</button><button class="btn" data-map="dietitian">Dietitian near me</button></div></section><section class="section"><ul class="list"><li class="item"><span class="date">Safety</span><div>Call emergency services for chest pain, severe breathing trouble, stroke signs, fainting, seizure, poisoning, severe allergy, uncontrolled bleeding, or self-harm risk.</div></li><li class="item"><span class="date">Storage</span><div>Your health logs are stored in this browser. AEGIS receives context only when you ask it or generate diet.</div></li></ul></section>`}
  function profileView(){const p=state.profile,g=goals();return `<section class="heroBand"><span class="tag">Profile</span><h2>${esc(p.name)}</h2><p>${p.age} years, ${p.gender}, ${p.height} cm, ${p.weight} kg</p></section><section class="section"><div class="cards">${metric('Water',g.water+' ml','Daily',100)}${metric('Steps',g.steps,'Daily',100)}${metric('Sleep',g.sleep+' h','Target',100)}${metric('Protein',g.protein+' g','Daily',100)}</div></section><section class="section"><button class="btn danger" data-action="reset">Reset app data</button></section>`}
  function chatView(){return `<section class="heroBand"><span class="tag">AEGIS chat</span><h2>Ask anything</h2><p>AEGIS uses your PulseMind data as context. The model runs on the server, not on user phones.</p></section><section class="section"><div class="chat">${chat.map(m=>`<div class="bubble ${m.role==='user'?'user':'assistant'}"><b>${m.role==='user'?'You':'AEGIS'}</b><p>${esc(m.text)}</p></div>`).join('')}${chatBusy?'<div class="bubble assistant"><b>AEGIS</b><p>Thinking...</p></div>':''}</div></section><section class="section"><form class="card grid" id="chatForm"><textarea class="textarea" name="message" placeholder="Ask symptoms, diet, sleep, workout, cycle, rhythm..." required></textarea><button class="btn primary">Ask AEGIS</button></form></section>`}
  function history(arr,title){if(!arr.length)return `<section class="section"><div class="card helper">No ${title.toLowerCase()} yet.</div></section>`;return `<section class="section"><div class="head"><h2>${title}</h2></div><ul class="list">${arr.slice(-6).reverse().map(e=>`<li class="item"><span class="date">${fmtDate(e.date||today())}</span><div>${esc(e.summary||e.note||e.symptoms||JSON.stringify(e))}</div></li>`).join('')}</ul></section>`}
  async function askAegis(msg){chatBusy=true;render();try{const res=await fetch(apiUrl('/api/aegis/chat'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:msg,context:context()})});const j=await res.json();chat.push({role:'assistant',text:j.answer||'AEGIS could not answer.'})}catch(e){chat.push({role:'assistant',text:'AEGIS server is not reachable. Start pulsemind_complete.py on the host device.'})}chatBusy=false;render()}
  function openMap(q){const go=(lat,lon)=>window.open(`https://www.google.com/maps/search/${encodeURIComponent(q)}/@${lat},${lon},14z`,'_blank');if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>go(p.coords.latitude,p.coords.longitude),()=>window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q+' near me')}`,'_blank'));else window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q+' near me')}`,'_blank')}
  document.addEventListener('click',e=>{const v=e.target.closest('[data-view]');if(v){view=v.dataset.view;render();return}const a=e.target.closest('[data-action]');if(a&&a.dataset.action==='diet')generateDiet();if(a&&a.dataset.action==='reset'&&confirm('Reset PulseMind data?')){resetStore();state=blank();view='today';dietPlan='';render()}const m=e.target.closest('[data-map]');if(m)openMap(m.dataset.map)})
  document.addEventListener('submit',e=>{e.preventDefault();const f=e.target,fd=formVals(f);if(f.id==='onboard'){state.profile={name:fd.name,age:num(fd.age),gender:fd.gender,height:num(fd.height),weight:num(fd.weight),focus:fd.focus};if(fd.gender==='female')state.profile.cycle={lastPeriod:fd.lastPeriod,cycleLength:num(fd.cycleLength,28),periodLength:num(fd.periodLength,5)};if(fd.gender==='male')state.profile.rhythm={wakeTime:fd.wakeTime||'06:30',bedTime:fd.bedTime||'22:30'};save();render()}if(f.id==='daily'){setDay(today(),{steps:num(fd.steps),water:num(fd.water),sleep:num(fd.sleep),exercise:num(fd.exercise),calories:num(fd.calories),protein:num(fd.protein),mood:num(fd.mood,3),stress:num(fd.stress,3),notes:fd.notes});dietPlan='';render()}if(f.id==='vitals'){state.vitals.push({date:today(),weight:num(fd.weight),heartRate:num(fd.heartRate),systolic:num(fd.systolic),diastolic:num(fd.diastolic),oxygen:num(fd.oxygen),temperature:num(fd.temperature),symptoms:fd.symptoms,summary:`Weight ${fd.weight||'--'} kg, HR ${fd.heartRate||'--'}, BP ${fd.systolic||'--'}/${fd.diastolic||'--'}, ${fd.symptoms||''}`});if(fd.weight)state.profile.weight=num(fd.weight);save();dietPlan='';render()}if(f.id==='journal'){state.journals.push({date:today(),note:fd.note});save();render()}if(f.id==='cycleLog'){state.cycleLogs.push({date:today(),flow:fd.flow,symptoms:fd.symptoms,summary:`${fd.flow} flow. ${fd.symptoms||''}`});if(fd.periodStarted)state.profile.cycle.lastPeriod=today();save();dietPlan='';render()}if(f.id==='rhythmLog'){setDay(today(),{wakeTime:fd.wakeTime,bedTime:fd.bedTime,morningLight:num(fd.morningLight),outdoorTime:num(fd.outdoorTime),sleepQuality:num(fd.sleepQuality,3),caffeineAfterCutoff:fd.caffeineAfterCutoff,screenCurfew:fd.screenCurfew?'yes':'no'});dietPlan='';render()}if(f.id==='chatForm'){const msg=fd.message;chat.push({role:'user',text:msg});f.reset();askAegis(msg)}})
  render();
  </script>
</body>
</html>'''


MANIFEST = {
    "name": "PulseMind Complete",
    "short_name": "PulseMind",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#f7fbf8",
    "theme_color": "#0f766e",
}


class PulseMindHandler(BaseHTTPRequestHandler):
    server_version = "PulseMindComplete/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{time.strftime('%H:%M:%S')}] {self.address_string()} {fmt % args}")

    def send_data(self, code: int, body: bytes, content_type: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, code: int, payload: dict[str, Any]) -> None:
        self.send_data(code, json_bytes(payload), "application/json; charset=utf-8")

    def read_json(self) -> dict[str, Any]:
        length = min(int(self.headers.get("Content-Length", "0")), REQUEST_LIMIT)
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_OPTIONS(self) -> None:
        self.send_json(200, {"ok": True})

    def do_GET(self) -> None:
        path = request_path(self.path)
        if path in ("/", "/index.html"):
            self.send_data(200, APP_HTML.encode("utf-8"), "text/html; charset=utf-8")
        elif path == "/manifest.webmanifest":
            self.send_json(200, MANIFEST)
        elif path == "/api/status":
            self.send_json(200, {"ok": True, "aegis": ollama_status(), "server": f"http://{local_ip()}:{APP_PORT}"})
        else:
            self.send_json(404, {"ok": False, "error": "Not found"})

    def do_POST(self) -> None:
        path = request_path(self.path)
        try:
            payload = self.read_json()
            context = payload.get("context") if isinstance(payload.get("context"), dict) else {}
            status = ollama_status()
            if path == "/api/aegis/chat":
                message = safe_text(payload.get("message"), 3000)
                if not message:
                    self.send_json(400, {"ok": False, "error": "Missing message"})
                    return
                if status["ollama_running"] and status["model_ready"]:
                    try:
                        answer = call_ollama(message, context)
                        source = "AEGIS DeepSeek-R1 on host"
                    except Exception:
                        answer = fallback_chat(message, context)
                        source = "AEGIS fallback"
                else:
                    answer = fallback_chat(message, context)
                    source = "AEGIS fallback"
                self.send_json(200, {"ok": True, "answer": answer, "source": source, "status": status})
                return
            if path == "/api/aegis/diet":
                if status["ollama_running"] and status["model_ready"]:
                    try:
                        answer = call_ollama(diet_prompt(context), context)
                        source = "AEGIS DeepSeek-R1 on host"
                    except Exception:
                        answer = fallback_diet(context)
                        source = "AEGIS fallback"
                else:
                    answer = fallback_diet(context)
                    source = "AEGIS fallback"
                self.send_json(200, {"ok": True, "answer": answer, "source": source, "status": status})
                return
            self.send_json(404, {"ok": False, "error": "Not found"})
        except Exception as exc:
            self.send_json(500, {"ok": False, "error": str(exc)})


def main() -> None:
    server = ThreadingHTTPServer((APP_HOST, APP_PORT), PulseMindHandler)
    lan = local_ip()
    print("PulseMind Complete is running.")
    print(f"Local:  http://127.0.0.1:{APP_PORT}")
    print(f"Phone:  http://{lan}:{APP_PORT}  (same Wi-Fi)")
    print(f"AEGIS:  Ollama host {OLLAMA_HOST}, model {OLLAMA_MODEL}")
    print("Keep this window open. Stop with Ctrl+C.")
    server.serve_forever()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nPulseMind stopped.")
        sys.exit(0)
